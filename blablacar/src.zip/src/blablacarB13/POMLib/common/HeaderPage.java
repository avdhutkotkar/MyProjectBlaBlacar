package blablacarB13.POMLib.common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

public class HeaderPage {
	String LogInButtonLoc = "//a[contains(text(),'Log in')]";
	//Sign up button
	//offer a ride button
	//bla bla car logo button
	
	public void clickOnSignIn (WebDriver driver){
		Reporter.log("Click on Log in Button on Header Page");
		driver.findElement(By.xpath(LogInButtonLoc)).click();
	}
	
}
